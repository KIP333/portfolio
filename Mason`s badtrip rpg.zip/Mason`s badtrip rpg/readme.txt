Mason`s badtrip rpg is a joke game, it is remake of another game Mason`s badtrip
this is the simple cooperative rpg 
you can play this only on discord server "Республика геймдев"